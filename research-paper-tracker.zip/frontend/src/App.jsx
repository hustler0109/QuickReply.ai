import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
export default function App() {
  return (
    <BrowserRouter>
      <nav>
        <Link to="/">Library</Link> | <Link to="/add">Add</Link> | <Link to="/analytics">Analytics</Link>
      </nav>
      <Routes>
        <Route path="/" element={<div>Library Page</div>} />
        <Route path="/add" element={<div>Add Paper Page</div>} />
        <Route path="/analytics" element={<div>Analytics Page</div>} />
      </Routes>
    </BrowserRouter>
  );
}
